Make sure data.txt exists in the same directory, and has the default format:
 	3 4 30
 	5 6 100

To compile and run hw4p4.py, execute "python3 hw4p4.py"
- It will write out the results to with change.txt
- The outputs will be seperated by -----------