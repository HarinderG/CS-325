Make sure 
 - data.txt exists in the same directory.
 - You have NumPy installed on the machine

To compile and run badSort.py, execute "python3 badSort.py"
- It will write out the results to with bad.out

To compile and run badSortTime.py, execute "python3 badSortTime.py"
 - The program will print out the time in seconds
 - It will go from 500 to 700 input values
 - It will also calculate for alpha = 2/3 and 3/4