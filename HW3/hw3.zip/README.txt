Before running the program, make sure data.txt is in this correct format.
Example:
1 10 mouse
3 25 cellphone
5 40 tablet
7 100 laptop

First column is item weight, second column is item value, and the 3rd column is item name.

To compile this assignment run "make".
To run this assignment run "./hw3 [weight capacity]".
	You must specify a weight capacity in the command line arg.
To zip the assignment again, run "make zip".
To remove all .o files, run "make clean".

The program will print out:
the knapsack
bag capacity
item count
maximum value found
List of all the items with their quantity