Make sure data.txt exists in the same directory.
To compile and run insertsort.py, execute "python3 insertsort.py"
To compile and run mergesort.py, execute "python3 mergesort.py"
- Both programs will write out the results to with insert.out or merge.out

To compile and run insertTime.py, execute "python3 insertTime.py"
To compile and run mergeTime.py, execute "python3 mergeTime.py"
 - Both programs will print out the runtime in seconds